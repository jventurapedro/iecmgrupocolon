
nota = input("Introduce una nota: ")
nota = float(nota)

if(nota >= 5):

    print("El alumno esta aprobado")

else:

    print("El alumno esta suspenso")