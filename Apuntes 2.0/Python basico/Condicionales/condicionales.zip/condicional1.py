
numero1 = input("Introduce un numero: ")
numero2 = input("Introduce un segundo numero: ")

if (numero1 > numero2):

    print("El primer numero es el mayor")

else:

    print("El segundo numero es el mayor")

print("Programa terminado")

